
import React, { useEffect, useState } from 'react'

export default function Home() {
  const [guilds, setGuilds] = useState<any[]>([])
  const [roles, setRoles] = useState<any[]>([])
  const [selectedGuild, setSelectedGuild] = useState<string>('')
  const [selectedRole, setSelectedRole] = useState<string>('')
  const [productId, setProductId] = useState<string>('prod_demo_1')
  const [tenantId, setTenantId] = useState<string>('00000000-0000-0000-0000-000000000000')
  const [status, setStatus] = useState<string>('')

  async function fetchGuilds() {
    const r = await fetch(process.env.NEXT_PUBLIC_API_BASE + '/v1/discord/guilds')
    try {
      const data = await r.json()
      setGuilds(Array.isArray(data) ? data : [])
    } catch {
      setGuilds([])
    }
  }

  async function fetchRoles(gid: string) {
    const r = await fetch(process.env.NEXT_PUBLIC_API_BASE + '/v1/discord/roles/' + gid)
    try {
      const data = await r.json()
      setRoles(Array.isArray(data) ? data : [])
    } catch {
      setRoles([])
    }
  }

  async function saveMapping() {
    setStatus('Saving...')
    const r = await fetch(process.env.NEXT_PUBLIC_API_BASE + '/v1/mappings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tenantId, productId, guildId: selectedGuild, roleId: selectedRole })
    })
    const data = await r.json()
    setStatus(data.ok ? 'Saved!' : ('Error: ' + (data.error || 'unknown')))
  }

  useEffect(() => { fetchGuilds() }, [])

  return (
    <main style={{ maxWidth: 820, margin: '40px auto', padding: 16, fontFamily: 'system-ui, sans-serif' }}>
      <h1>WhopSync — Quick Setup</h1>
      <p>1) Invite your Discord bot to your server (with Manage Roles). 2) Select a server and role. 3) Enter your Whop Product ID. 4) Click Save Mapping.</p>

      <div style={{ border: '1px solid #ddd', padding: 16, borderRadius: 8, marginTop: 16 }}>
        <label>Tenant ID<br/>
          <input value={tenantId} onChange={e => setTenantId(e.target.value)} style={{ width:'100%' }} />
        </label>
        <br/><br/>
        <label>Whop Product ID<br/>
          <input value={productId} onChange={e => setProductId(e.target.value)} style={{ width:'100%' }} />
        </label>

        <div style={{ display:'flex', gap:16, marginTop:16 }}>
          <div style={{ flex:1 }}>
            <label>Discord Server<br/>
              <select value={selectedGuild} onChange={e => { setSelectedGuild(e.target.value); fetchRoles(e.target.value) }} style={{ width:'100%' }}>
                <option value="">Select a server…</option>
                {guilds.map((g:any) => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </label>
          </div>
          <div style={{ flex:1 }}>
            <label>Role<br/>
              <select value={selectedRole} onChange={e => setSelectedRole(e.target.value)} style={{ width:'100%' }}>
                <option value="">Select a role…</option>
                {roles.map((r:any) => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </label>
          </div>
        </div>
        <button onClick={saveMapping} style={{ marginTop:16, padding:'10px 16px' }}>Save Mapping</button>
        <div style={{ marginTop:8, minHeight:24 }}>{status}</div>
      </div>

      <p style={{ marginTop:24 }}>API Base: <code>{process.env.NEXT_PUBLIC_API_BASE || '(set NEXT_PUBLIC_API_BASE)'}</code></p>
    <p style={{ marginTop:24 }}>Go to <a href='/crm'>CRM Settings</a></p></main>
  )
}
