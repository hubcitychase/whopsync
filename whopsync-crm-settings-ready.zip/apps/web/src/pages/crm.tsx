
import React, { useEffect, useState } from 'react'

export default function CRMSettings() {
  const [tenantId, setTenantId] = useState('00000000-0000-0000-0000-000000000000')
  const [notionEnabled, setNotionEnabled] = useState(false)
  const [sheetsEnabled, setSheetsEnabled] = useState(false)
  const [notionDbId, setNotionDbId] = useState('')
  const [sheetsSpreadsheetId, setSheetsSpreadsheetId] = useState('')
  const [sheetsWorksheetName, setSheetsWorksheetName] = useState('Purchases')
  const [status, setStatus] = useState('')

  async function load() {
    setStatus('Loading...')
    const r = await fetch((process.env.NEXT_PUBLIC_API_BASE || '') + '/v1/crm/settings', {
      headers: { 'x-tenant-id': tenantId }
    })
    const j = await r.json()
    if (j?.data) {
      setNotionEnabled(!!j.data.notionEnabled)
      setSheetsEnabled(!!j.data.sheetsEnabled)
      setNotionDbId(j.data.notionDbId || '')
      setSheetsSpreadsheetId(j.data.sheetsSpreadsheetId || '')
      setSheetsWorksheetName(j.data.sheetsWorksheetName || 'Purchases')
    }
    setStatus('')
  }

  async function save() {
    setStatus('Saving...')
    const r = await fetch((process.env.NEXT_PUBLIC_API_BASE || '') + '/v1/crm/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-tenant-id': tenantId },
      body: JSON.stringify({ notionEnabled, sheetsEnabled, notionDbId, sheetsSpreadsheetId, sheetsWorksheetName })
    })
    const j = await r.json()
    setStatus(j.ok ? 'Saved!' : 'Error')
  }

  useEffect(() => { load() }, [])

  return (
    <main style={{ maxWidth: 720, margin: '40px auto', padding: 16 }}>
      <h1>CRM Settings</h1>
      <p>Turn on Notion or Google Sheets logging without editing any files.</p>

      <label>Tenant ID<br/>
        <input value={tenantId} onChange={e => setTenantId(e.target.value)} style={{ width:'100%' }} />
      </label>
      <div style={{ display:'flex', gap:24, marginTop:16 }}>
        <label><input type="checkbox" checked={notionEnabled} onChange={e => setNotionEnabled(e.target.checked)} /> Enable Notion</label>
        <label><input type="checkbox" checked={sheetsEnabled} onChange={e => setSheetsEnabled(e.target.checked)} /> Enable Google Sheets</label>
      </div>

      <div style={{ marginTop:16, border:'1px solid #ddd', padding:16, borderRadius:8 }}>
        <h3>Notion</h3>
        <label>Notion Database ID<br/>
          <input value={notionDbId} onChange={e => setNotionDbId(e.target.value)} style={{ width:'100%' }} />
        </label>
        <p style={{ color:'#555' }}>Use an internal integration token on the API/Worker for authentication.</p>
      </div>

      <div style={{ marginTop:16, border:'1px solid #ddd', padding:16, borderRadius:8 }}>
        <h3>Google Sheets</h3>
        <label>Spreadsheet ID<br/>
          <input value={sheetsSpreadsheetId} onChange={e => setSheetsSpreadsheetId(e.target.value)} style={{ width:'100%' }} />
        </label>
        <label>Worksheet (tab) name<br/>
          <input value={sheetsWorksheetName} onChange={e => setSheetsWorksheetName(e.target.value)} style={{ width:'100%' }} />
        </label>
        <p style={{ color:'#555' }}>Share the sheet with your service account email (Editor).</p>
      </div>

      <button onClick={save} style={{ marginTop:16, padding:'10px 16px' }}>Save Settings</button>
      <div style={{ marginTop:8, minHeight:24 }}>{status}</div>

      <p style={{ marginTop:24 }}>
        Back to <a href="/">Role Mapping</a>
      </p>
    </main>
  )
}
