
import 'dotenv/config'
import { Worker, QueueEvents, JobsOptions } from 'bullmq'
import { PrismaClient } from '@prisma/client'
import fetch from 'node-fetch'

import crypto from 'crypto'

// ---------------- CRM Helpers ----------------

async function getCRMSettings(tenantId: string) {
  const s = await prisma.cRMSetting.findFirst({ where: { tenantId }})
  return {
    notionEnabled: s ? s.notionEnabled : (String(process.env.CRM_SYNC_NOTION_ENABLED || 'false') === 'true'),
    sheetsEnabled: s ? s.sheetsEnabled : (String(process.env.CRM_SYNC_SHEETS_ENABLED || 'false') === 'true'),
    notionDbId: s?.notionDbId || process.env.NOTION_DB_ID,
    sheetsSpreadsheetId: s?.sheetsSpreadsheetId || process.env.SHEETS_SPREADSHEET_ID,
    sheetsWorksheetName: s?.sheetsWorksheetName || process.env.SHEETS_WORKSHEET_NAME || 'Purchases',
  }
}

function fromB64ToJSON(b64?: string) {
  if (!b64) return undefined
  try { return JSON.parse(Buffer.from(b64, 'base64').toString('utf-8')) } catch { return undefined }
}

async function notionUpsert({ dbId, token, email, customerId, productId, status }:
  { dbId:string, token:string, email?:string, customerId:string, productId?:string, status:'active'|'canceled'|'expired' }) {
  // This is a simplified upsert: we always create and let users dedupe if needed.
  const body:any = {
    parent: { database_id: dbId },
    properties: {
      Email: email ? { title: [{ text: { content: email }}] } : { title: [{ text: { content: customerId }}] },
      CustomerId: { rich_text: [{ text: { content: customerId }}] },
      ProductId: { rich_text: [{ text: { content: productId || '' }}] },
      Status: { select: { name: status } },
      LastEventAt: { date: { start: new Date().toISOString() } }
    }
  }
  const r = await fetch('https://api.notion.com/v1/pages', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Notion-Version': '2022-06-28',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  })
  if (!r.ok) {
    const text = await r.text()
    throw new Error('Notion error: ' + r.status + ' ' + text)
  }
}

async function sheetsAppend({ spreadsheetId, worksheet, saB64, values }:
  { spreadsheetId:string, worksheet:string, saB64:string, values:any[] }) {
  // Minimal JWT auth flow for service account using Google's REST API would require signing a JWT.
  // For simplicity in this starter, we use the "published CSV append proxy" approach:
  // In production, replace with googleapis library.
  // Here, we no-op to keep the worker self-contained.
  return true
}

const prisma = new PrismaClient()

const connection = { connection: { url: process.env.REDIS_URL! }}
const worker = new Worker('whop-events', async job => {
  const e = await prisma.webhookEvent.findUnique({ where: { id: job.data.id }})
  if (!e) return

  try {
    switch (e.type) {
      case 'purchase.created':
        await handlePurchase(e.tenantId, e.payload as any)
        break
      case 'subscription.canceled':
      case 'access.revoked':
        await handleCancel(e.tenantId, e.payload as any)
        break
      default:
        // mark as ok if not handled
        break
    }
    await prisma.webhookEvent.update({ where: { id: e.id }, data: { status: 'ok', processedAt: new Date() }})
  } catch (err:any) {
    await prisma.webhookEvent.update({ where: { id: e.id }, data: { status: 'error', error: err.message }})
    throw err
  }
}, connection as any)

new QueueEvents('whop-events', connection as any)

async function handlePurchase(tenantId: string, payload: any) {
  const customerId = payload.data?.customer_id
  const productId = payload.data?.product_id


const email = payload.data?.customer_email || payload.data?.email
const notionEnabled = String(process.env.CRM_SYNC_NOTION_ENABLED || 'false') === 'true'
const sheetsEnabled = String(process.env.CRM_SYNC_SHEETS_ENABLED || 'false') === 'true'

if (notionEnabled) {
  const notionToken = process.env.NOTION_CLIENT_SECRET || process.env.NOTION_TOKEN
  const notionDb = process.env.NOTION_DB_ID!
  if (notionToken && notionDb) {
    await notionUpsert({ dbId: notionDb, token: notionToken, email, customerId, productId, status: 'active' })
  }
}
if (sheetsEnabled) {
  const sid = process.env.SHEETS_SPREADSHEET_ID!
  const ws = process.env.SHEETS_WORKSHEET_NAME || 'Purchases'
  const sa = process.env.GOOGLE_SERVICE_ACCOUNT_B64 || ''
  await sheetsAppend({ spreadsheetId: sid, worksheet: ws, saB64: sa, values: [new Date().toISOString(), customerId, productId, 'purchase'] })
}

  // Upsert entitlement
  await prisma.entitlement.upsert({
    where: { id: `${tenantId}:${customerId}:${productId}` },
    update: { status: 'active', updatedAt: new Date() },
    create: {
      id: `${tenantId}:${customerId}:${productId}`,
      tenantId, customerId, productId,
      status: 'active', startedAt: new Date()
    }
  })

  // TODO: read mappings and call Discord API
  // log activity

const email = payload.data?.customer_email || payload.data?.email
const notionEnabled = String(process.env.CRM_SYNC_NOTION_ENABLED || 'false') === 'true'
const sheetsEnabled = String(process.env.CRM_SYNC_SHEETS_ENABLED || 'false') === 'true'

if (notionEnabled) {
  const notionToken = process.env.NOTION_CLIENT_SECRET || process.env.NOTION_TOKEN
  const notionDb = process.env.NOTION_DB_ID!
  if (notionToken && notionDb) {
    await notionUpsert({ dbId: notionDb, token: notionToken, email, customerId, productId, status: 'canceled' })
  }
}
if (sheetsEnabled) {
  const sid = process.env.SHEETS_SPREADSHEET_ID!
  const ws = process.env.SHEETS_WORKSHEET_NAME || 'Purchases'
  const sa = process.env.GOOGLE_SERVICE_ACCOUNT_B64 || ''
  await sheetsAppend({ spreadsheetId: sid, worksheet: ws, saB64: sa, values: [new Date().toISOString(), customerId, productId, 'canceled'] })
}

  await prisma.activityLog.create({
    data: { tenantId, customerId, productId, action: 'assign_role', outcome: 'success', message: 'Role assignment queued' }
  })
}

async function handleCancel(tenantId: string, payload: any) {
  const customerId = payload.data?.customer_id
  const productId = payload.data?.product_id
  await prisma.activityLog.create({
    data: { tenantId, customerId, productId, action: 'remove_role', outcome: 'success', message: 'Role removal queued' }
  })
}
