# WhopSync — Owner’s Guide (Plain English)

**Goal:** You sell an app on Whop that automatically gives/removes Discord roles and logs customers to your CRM. You don’t need to code.

## What you will do (the only 4 things)
1) Create accounts (free): **Whop**, **Discord**, **Vercel**, **Render**, **Neon**, **Upstash**.
2) Paste the secrets into one settings page I’ll give you (the `.env` file).
3) Click the deploy buttons (copy/paste commands included).
4) Connect your Discord server and pick which Whop product gives which role.

That’s it. Everything else is prebuilt.

## What I’ve chosen for you (easiest + reliable)
- **Web Dashboard:** Vercel (simple, fast)
- **API + Worker:** Render (no ops headaches)
- **Database:** Neon Postgres (free tier to start)
- **Queue/Cache:** Upstash Redis (free tier to start)

## What the app actually does
- When someone buys on **Whop**, a secure message (“webhook”) hits your API.
- The API queues a job → the worker gives the buyer the correct **Discord role**.
- If they cancel/expire, the role is removed. Logs are stored. CRM row updated (optional).

## Day-to-day usage
- You don’t touch servers.
- In the dashboard, you can see recent events and mappings.
- You can pause automations per product at any time.

## How to get support
- If something breaks, you’ll see a clear error banner in the dashboard + a retry button.
- You can export logs to CSV for audits or refunds.
