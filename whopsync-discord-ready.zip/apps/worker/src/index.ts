
import 'dotenv/config'
import { Worker, QueueEvents, JobsOptions } from 'bullmq'
import { PrismaClient } from '@prisma/client'
import fetch from 'node-fetch'

const prisma = new PrismaClient()

const connection = { connection: { url: process.env.REDIS_URL! }}
const worker = new Worker('whop-events', async job => {
  const e = await prisma.webhookEvent.findUnique({ where: { id: job.data.id }})
  if (!e) return

  try {
    switch (e.type) {
      case 'purchase.created':
        await handlePurchase(e.tenantId, e.payload as any)
        break
      case 'subscription.canceled':
      case 'access.revoked':
        await handleCancel(e.tenantId, e.payload as any)
        break
      default:
        // mark as ok if not handled
        break
    }
    await prisma.webhookEvent.update({ where: { id: e.id }, data: { status: 'ok', processedAt: new Date() }})
  } catch (err:any) {
    await prisma.webhookEvent.update({ where: { id: e.id }, data: { status: 'error', error: err.message }})
    throw err
  }
}, connection as any)

new QueueEvents('whop-events', connection as any)

async function handlePurchase(tenantId: string, payload: any) {
  const customerId = payload.data?.customer_id
  const productId = payload.data?.product_id

  // Upsert entitlement
  await prisma.entitlement.upsert({
    where: { id: `${tenantId}:${customerId}:${productId}` },
    update: { status: 'active', updatedAt: new Date() },
    create: {
      id: `${tenantId}:${customerId}:${productId}`,
      tenantId, customerId, productId,
      status: 'active', startedAt: new Date()
    }
  })

  // TODO: read mappings and call Discord API
  // log activity
  await prisma.activityLog.create({
    data: { tenantId, customerId, productId, action: 'assign_role', outcome: 'success', message: 'Role assignment queued' }
  })
}

async function handleCancel(tenantId: string, payload: any) {
  const customerId = payload.data?.customer_id
  const productId = payload.data?.product_id
  await prisma.activityLog.create({
    data: { tenantId, customerId, productId, action: 'remove_role', outcome: 'success', message: 'Role removal queued' }
  })
}
