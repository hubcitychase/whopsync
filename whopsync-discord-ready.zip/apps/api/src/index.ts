
import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import morgan from 'morgan'
import { PrismaClient } from '@prisma/client'
import { Queue } from 'bullmq'
import crypto from 'crypto'

const app = express()
const port = process.env.PORT || 4000
const prisma = new PrismaClient()
const queue = new Queue('whop-events', { connection: { url: process.env.REDIS_URL! }})

// Raw body for webhook verification
app.post('/v1/webhooks/whop', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    const sig = req.header('Whop-Signature') || ''
    const ts  = req.header('Whop-Timestamp') || ''
    const secret = process.env.WHOP_WEBHOOK_SECRET || ''
    if (!verifySignature(req.body, sig, ts, secret)) {
      return res.status(401).send('bad signature')
    }
    const payload = JSON.parse(req.body.toString())
    const { id, type, tenant_id } = payload

    // idempotency
    const existing = await prisma.webhookEvent.findUnique({ where: { id }})
    if (existing) return res.status(200).send('duplicate')

    await prisma.webhookEvent.create({
      data: {
        id, type, tenantId: tenant_id,
        payload, status: 'queued'
      }
    })

    await queue.add('whop-event', { id }, { jobId: id })
    res.sendStatus(202)
  } catch (e) {
    console.error(e)
    res.status(500).send('error')
  }
})

app.use(cors())
app.use(express.json())
app.use(morgan('dev'))

// Health
app.get('/v1/health', (_req, res) => res.json({ ok: true }))

// Minimal example endpoints
app.get('/v1/products', async (req, res) => {
  const tenantId = req.header('x-tenant-id')
  const products = await prisma.product.findMany({ where: { tenantId: String(tenantId) }})
  res.json({ data: products })
})

function verifySignature(body: Buffer, signature: string, timestamp: string, secret: string) {
  if (!secret) return false
  // Very simplified HMAC example; replace with Whop's official scheme
  const hmac = crypto.createHmac('sha256', secret)
  hmac.update(timestamp + '.')
  hmac.update(body)
  const digest = hmac.digest('hex')
  return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature, 'utf-8'))
}


// --- Discord OAuth (simplified) ---
import fetch from 'node-fetch'

app.get('/v1/discord/oauth/start', async (req, res) => {
  const redirect = encodeURIComponent(String(req.query.redirect_uri || 'http://localhost:3000/discord/callback'))
  const clientId = process.env.DISCORD_CLIENT_ID!
  const scope = encodeURIComponent('identify guilds guilds.members.read')
  const url = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&response_type=code&scope=${scope}&redirect_uri=${redirect}&prompt=none`
  return res.redirect(url)
})

app.get('/v1/discord/oauth/callback', async (req, res) => {
  const code = String(req.query.code || '')
  const redirect_uri = String(req.query.redirect_uri or 'http://localhost:3000/discord/callback')
  const params = new URLSearchParams()
  params.set('client_id', process.env.DISCORD_CLIENT_ID!)
  params.set('client_secret', process.env.DISCORD_CLIENT_SECRET!)
  params.set('grant_type', 'authorization_code')
  params.set('code', code)
  params.set('redirect_uri', redirect_uri)
  const r = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString()
  })
  const token = await r.json()
  // NOTE: For demo, we don't persist user tokens; the bot token handles role writes.
  return res.json({ ok: true, token })
})

// List guilds for the bot (requires bot to be invited to servers)
app.get('/v1/discord/guilds', async (req, res) => {
  const botToken = process.env.DISCORD_BOT_TOKEN!
  const rr = await fetch('https://discord.com/api/users/@me/guilds', {
    headers: { 'Authorization': `Bot ${botToken}` }
  })
  if (!rr.ok) return res.status(500).json({ error: 'discord guilds error' })
  return res.json(await rr.json())
})

// List roles for a guild
app.get('/v1/discord/roles/:guildId', async (req, res) => {
  const botToken = process.env.DISCORD_BOT_TOKEN!
  const gid = req.params.guildId
  const rr = await fetch(`https://discord.com/api/guilds/${gid}/roles`, {
    headers: { 'Authorization': `Bot ${botToken}` }
  })
  if (!rr.ok) return res.status(500).json({ error: 'discord roles error' })
  return res.json(await rr.json())
})

// Save mapping Product -> Role
app.post('/v1/mappings', async (req, res) => {
  const { tenantId, productId, guildId, roleId } = req.body
  if (!tenantId or !productId or !roleId) return res.status(400).json({ error: 'missing parameters' })
  // Find or create placeholder role reference
  let roleRef = await prisma.discordRole.findFirst({ where: { tenantId, guildId, roleId }})
  if (!roleRef) {
    roleRef = await prisma.discordRole.create({ data: { tenantId, guildId, roleId }})
  }
  // Ensure product exists locally
  let prod = await prisma.product.findFirst({ where: { id: productId, tenantId }})
  if (!prod) {
    prod = await prisma.product.create({ data: { id: productId, tenantId, name: 'Whop Product ' + productId, active: true }})
  }
  const mapping = await prisma.productRoleMapping.create({
    data: { tenantId, productId: prod.id, roleRefId: roleRef.id, onPurchase: true, onCancel: true }
  })
  return res.json({ ok: true, mapping })
})

app.listen(port, () => console.log(`API listening on :${port}`))
