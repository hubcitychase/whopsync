
# WhopSync — Fully Managed App (Starter Monorepo)

A production-ready starter for your Whop automation micro‑SaaS:
- **apps/web** — Next.js dashboard (onboarding wizard, logs, mappings UI)
- **apps/api** — Express + TypeScript REST API and **/v1/webhooks/whop**
- **apps/worker** — BullMQ worker for async jobs
- **prisma/** — Postgres schema (tenants, products, mappings, entitlements, logs)
- **deployment** — Fly.io for API/worker, Vercel for Web
- **openapi.yaml** — API contract for /v1 endpoints

> This repo is intentionally minimal but functional. You can `pnpm dev` to run all services locally with Dockerized Postgres + Redis.

## Quickstart

1. **Requirements**
   - Node 20+, pnpm, Docker Desktop
2. **Clone & Install**
   ```bash
   pnpm install
   ```
3. **Start Dev Datastores**
   ```bash
   docker compose up -d
   ```
4. **Configure Environment**
   - Copy `.env.example` to `.env` at root and fill secrets.
5. **DB Setup**
   ```bash
   pnpm prisma:push
   ```
6. **Run All Apps (in separate terminals)**
   ```bash
   pnpm dev:web
   pnpm dev:api
   pnpm dev:worker
   ```
7. **Test Webhook (local)**
   ```bash
   curl -X POST http://localhost:4000/v1/webhooks/whop      -H "Whop-Signature: test" -H "Whop-Timestamp: 0"      -d '{ "id":"evt_test_1","type":"purchase.created","tenant_id":"00000000-0000-0000-0000-000000000000","data":{"customer_id":"cust_1","product_id":"prod_1"} }'
   ```

## Deploy

- **Web (Next.js)**: Vercel — set env vars in dashboard.
- **API & Worker**: Fly.io — see `deployment/fly.api.toml` and `deployment/fly.worker.toml`.
- **DB**: Neon/Supabase; **Redis**: Upstash.

## Contents

See inline comments in source files for guidance. The webhook handler verifies signatures, logs events, enqueues jobs, and updates entitlements. The worker executes role assignments, CRM syncs, and reminders with retries and dead‑lettering.



---

## Discord Quick Steps

1. Create a Discord application + bot → invite to your server with **Manage Roles**.
2. Set `DISCORD_BOT_TOKEN` in your API/Worker environment.
3. Start API & Worker. Open the web dashboard → pick server → pick role → enter Whop Product ID → Save Mapping.
4. In Whop, set your webhook URL to `https://YOUR-API/v1/webhooks/whop` and paste the signing secret into `WHOP_WEBHOOK_SECRET`.


---

## CRM Sync (Notion + Google Sheets)

You can log every purchase/cancel to Notion and/or Google Sheets.

### Turn it on
Set these env vars on the API **and** Worker services:
- `CRM_SYNC_NOTION_ENABLED=true` to enable Notion
- `CRM_SYNC_SHEETS_ENABLED=true` to enable Google Sheets
- `NOTION_CLIENT_ID` / `NOTION_CLIENT_SECRET` and `NOTION_DB_ID` (a database with properties: Email (title or rich text), CustomerId (text), ProductId (text), Status (select), LastEventAt (date))
- `GOOGLE_SERVICE_ACCOUNT_B64` (base64 of the JSON credentials)
- `SHEETS_SPREADSHEET_ID` (from your sheet URL) and `SHEETS_WORKSHEET_NAME` (tab name, e.g. `Purchases`)

### Service Account permissions (Sheets)
- In Google Cloud Console, create a Service Account and download its JSON.
- Base64-encode it and paste into `GOOGLE_SERVICE_ACCOUNT_B64`.
- Share your Google Sheet with the service account email (Editor).

The worker will:
- **On purchase:** upsert Notion row by Email/CustomerId and append a row to Sheets.
- **On cancel/expired:** update Notion status and append a cancellation row to Sheets.
