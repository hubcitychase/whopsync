
import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import morgan from 'morgan'
import { PrismaClient } from '@prisma/client'
import { Queue } from 'bullmq'
import crypto from 'crypto'

const app = express()
const port = process.env.PORT || 4000
const prisma = new PrismaClient()
const queue = new Queue('whop-events', { connection: { url: process.env.REDIS_URL! }})

// Raw body for webhook verification
app.post('/v1/webhooks/whop', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    const sig = req.header('Whop-Signature') || ''
    const ts  = req.header('Whop-Timestamp') || ''
    const secret = process.env.WHOP_WEBHOOK_SECRET || ''
    if (!verifySignature(req.body, sig, ts, secret)) {
      return res.status(401).send('bad signature')
    }
    const payload = JSON.parse(req.body.toString())
    const { id, type, tenant_id } = payload

    // idempotency
    const existing = await prisma.webhookEvent.findUnique({ where: { id }})
    if (existing) return res.status(200).send('duplicate')

    await prisma.webhookEvent.create({
      data: {
        id, type, tenantId: tenant_id,
        payload, status: 'queued'
      }
    })

    await queue.add('whop-event', { id }, { jobId: id })
    res.sendStatus(202)
  } catch (e) {
    console.error(e)
    res.status(500).send('error')
  }
})

app.use(cors())
app.use(express.json())
app.use(morgan('dev'))

// Health
app.get('/v1/health', (_req, res) => res.json({ ok: true }))

// Minimal example endpoints
app.get('/v1/products', async (req, res) => {
  const tenantId = req.header('x-tenant-id')
  const products = await prisma.product.findMany({ where: { tenantId: String(tenantId) }})
  res.json({ data: products })
})

function verifySignature(body: Buffer, signature: string, timestamp: string, secret: string) {
  if (!secret) return false
  // Very simplified HMAC example; replace with Whop's official scheme
  const hmac = crypto.createHmac('sha256', secret)
  hmac.update(timestamp + '.')
  hmac.update(body)
  const digest = hmac.digest('hex')
  return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature, 'utf-8'))
}

app.listen(port, () => console.log(`API listening on :${port}`))
