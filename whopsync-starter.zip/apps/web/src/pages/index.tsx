
import React from 'react'

export default function Home() {
  return (
    <main style={{ maxWidth: 720, margin: '40px auto', padding: 16 }}>
      <h1>WhopSync Dashboard</h1>
      <p>Welcome! Use the onboarding wizard to connect Whop, Discord, and your CRM.</p>
      <ol>
        <li>Paste your Whop Webhook secret in API settings</li>
        <li>Connect Discord (OAuth)</li>
        <li>Sync Whop products</li>
        <li>Map product tiers to Discord roles</li>
        <li>Run a test purchase simulation</li>
      </ol>
    </main>
  )
}
